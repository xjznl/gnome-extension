import Adw from 'gi://Adw';
import Gio from 'gi://Gio';
import Gtk from 'gi://Gtk';
import Gdk from 'gi://Gdk';
import {ExtensionPreferences, gettext as _} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class NetSpeedVerticalPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        const page = new Adw.PreferencesPage({
            title: '网速设置',
            icon_name: 'preferences-system-symbolic',
        });
        window.add(page);

        // --- 实时预览分组 ---
        const previewGroup = new Adw.PreferencesGroup({
            title: '实时预览',
            description: '顶栏状态栏中的显示效果预览',
        });
        page.add(previewGroup);

        const previewRow = new Adw.ActionRow({
            title: '状态栏样式预览',
        });

        const previewBox = new Gtk.Box({
            orientation: Gtk.Orientation.VERTICAL,
            spacing: 2,
            valign: Gtk.Align.CENTER,
            margin_top: 4,
            margin_bottom: 4,
        });

        const previewUpload = new Gtk.Label({
            xalign: 0,
            use_markup: true,
        });

        const previewDownload = new Gtk.Label({
            xalign: 0,
            use_markup: true,
        });

        previewBox.append(previewUpload);
        previewBox.append(previewDownload);
        previewRow.add_suffix(previewBox);
        previewGroup.add(previewRow);

        const updatePreview = () => {
            const upCol = settings.get_string('upload-color') || '#33d17a';
            const downCol = settings.get_string('download-color') || '#3584e4';
            const font = settings.get_string('font-family') || 'Monospace';
            const size = settings.get_int('font-size') || 8;
            const bold = settings.get_boolean('font-bold');
            const upPre = settings.get_string('upload-prefix') || '▲';
            const downPre = settings.get_string('download-prefix') || '▼';
            const weightAttr = bold ? ' weight="bold"' : '';

            previewUpload.set_markup(
                `<span foreground="${upCol}" font_family="${font}" font_size="${size * 1024}"${weightAttr}>${upPre}    42  B/s</span>`
            );
            previewDownload.set_markup(
                `<span foreground="${downCol}" font_family="${font}" font_size="${size * 1024}"${weightAttr}>${downPre}  12.5 KB/s</span>`
            );
        };

        // --- 颜色设置分组 ---
        const colorGroup = new Adw.PreferencesGroup({
            title: '颜色设置',
            description: '自定义上传和下载网速的文字颜色',
        });
        page.add(colorGroup);

        const createColorButton = (key) => {
            const currentHex = settings.get_string(key) || '#ffffff';
            const rgba = new Gdk.RGBA();
            rgba.parse(currentHex);

            if (Gtk.ColorDialogButton) {
                const dialog = new Gtk.ColorDialog({ with_alpha: false });
                const btn = new Gtk.ColorDialogButton({
                    dialog: dialog,
                    rgba: rgba,
                    valign: Gtk.Align.CENTER,
                });
                btn.connect('notify::rgba', () => {
                    const c = btn.get_rgba();
                    const r = Math.round(c.red * 255).toString(16).padStart(2, '0');
                    const g = Math.round(c.green * 255).toString(16).padStart(2, '0');
                    const b = Math.round(c.blue * 255).toString(16).padStart(2, '0');
                    settings.set_string(key, `#${r}${g}${b}`);
                });
                return btn;
            } else if (Gtk.ColorButton) {
                const btn = new Gtk.ColorButton({
                    rgba: rgba,
                    valign: Gtk.Align.CENTER,
                });
                btn.connect('color-set', () => {
                    const c = btn.get_rgba();
                    const r = Math.round(c.red * 255).toString(16).padStart(2, '0');
                    const g = Math.round(c.green * 255).toString(16).padStart(2, '0');
                    const b = Math.round(c.blue * 255).toString(16).padStart(2, '0');
                    settings.set_string(key, `#${r}${g}${b}`);
                });
                return btn;
            }
            return new Gtk.Box();
        };

        // 上传颜色
        const uploadColorRow = new Adw.ActionRow({
            title: '上传网速颜色',
            subtitle: settings.get_string('upload-color'),
        });
        uploadColorRow.add_suffix(createColorButton('upload-color'));
        colorGroup.add(uploadColorRow);

        settings.connect('changed::upload-color', () => {
            uploadColorRow.set_subtitle(settings.get_string('upload-color'));
            updatePreview();
        });

        // 下载颜色
        const downloadColorRow = new Adw.ActionRow({
            title: '下载网速颜色',
            subtitle: settings.get_string('download-color'),
        });
        downloadColorRow.add_suffix(createColorButton('download-color'));
        colorGroup.add(downloadColorRow);

        settings.connect('changed::download-color', () => {
            downloadColorRow.set_subtitle(settings.get_string('download-color'));
            updatePreview();
        });

        // --- 字体与排版分组 ---
        const fontGroup = new Adw.PreferencesGroup({
            title: '字体与排版',
            description: '自定义字体名称、字号大小与粗体样式',
        });
        page.add(fontGroup);

        // 字体名称
        const fontEntryRow = new Adw.EntryRow({
            title: '字体名称',
            text: settings.get_string('font-family') || 'Monospace',
        });
        fontEntryRow.connect('changed', () => {
            settings.set_string('font-family', fontEntryRow.get_text() || 'Monospace');
            updatePreview();
        });
        fontGroup.add(fontEntryRow);

        // 字体大小
        const fontAdj = new Gtk.Adjustment({
            lower: 6,
            upper: 18,
            step_increment: 1,
            value: settings.get_int('font-size') || 8,
        });
        const fontSizeRow = new Adw.SpinRow({
            title: '字体大小 (pt)',
            subtitle: '建议设为 7–10 pt 以适应顶栏高度',
            adjustment: fontAdj,
        });
        fontAdj.connect('value-changed', () => {
            settings.set_int('font-size', Math.round(fontAdj.get_value()));
            updatePreview();
        });
        fontGroup.add(fontSizeRow);

        // 粗体开关
        const boldRow = new Adw.SwitchRow({
            title: '粗体显示',
            subtitle: '加粗显示网速文字',
            active: settings.get_boolean('font-bold'),
        });
        boldRow.connect('notify::active', () => {
            settings.set_boolean('font-bold', boldRow.get_active());
            updatePreview();
        });
        fontGroup.add(boldRow);

        // --- 行为与符号分组 ---
        const optionsGroup = new Adw.PreferencesGroup({
            title: '行为与前缀符号',
            description: '设置刷新频率与上传/下载前缀符号',
        });
        page.add(optionsGroup);

        // 刷新间隔
        const intervalAdj = new Gtk.Adjustment({
            lower: 1,
            upper: 10,
            step_increment: 1,
            value: settings.get_int('refresh-interval') || 1,
        });
        const intervalRow = new Adw.SpinRow({
            title: '刷新间隔 (秒)',
            subtitle: '网速更新的时间间隔',
            adjustment: intervalAdj,
        });
        intervalAdj.connect('value-changed', () => {
            settings.set_int('refresh-interval', Math.round(intervalAdj.get_value()));
        });
        optionsGroup.add(intervalRow);

        // 上传前缀
        const upPrefixRow = new Adw.EntryRow({
            title: '上传前缀符号',
            text: settings.get_string('upload-prefix') || '▲',
        });
        upPrefixRow.connect('changed', () => {
            settings.set_string('upload-prefix', upPrefixRow.get_text() || '▲');
            updatePreview();
        });
        optionsGroup.add(upPrefixRow);

        // 下载前缀
        const downPrefixRow = new Adw.EntryRow({
            title: '下载前缀符号',
            text: settings.get_string('download-prefix') || '▼',
        });
        downPrefixRow.connect('changed', () => {
            settings.set_string('download-prefix', downPrefixRow.get_text() || '▼');
            updatePreview();
        });
        optionsGroup.add(downPrefixRow);

        updatePreview();
    }
}
