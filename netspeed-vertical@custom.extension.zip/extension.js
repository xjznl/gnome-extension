import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import St from 'gi://St';
import Gio from 'gi://Gio';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {Extension, gettext as _} from 'resource:///org/gnome/shell/extensions/extension.js';

const NetSpeedIndicator = GObject.registerClass(
class NetSpeedIndicator extends PanelMenu.Button {
    _init(settings, openPrefs) {
        super._init(0.5, _('Net Speed Indicator'));
        this._settings = settings;
        this._openPrefs = openPrefs;

        // 垂直布局容器（兼容 GNOME 45 至 GNOME 51+）
        let box;
        try {
            box = new St.BoxLayout({
                orientation: Clutter.Orientation.VERTICAL,
                y_align: Clutter.ActorAlign.CENTER,
                x_align: Clutter.ActorAlign.CENTER,
                style_class: 'net-speed-container',
            });
        } catch (e1) {
            box = new St.BoxLayout({
                vertical: true,
                y_align: Clutter.ActorAlign.CENTER,
                x_align: Clutter.ActorAlign.CENTER,
                style_class: 'net-speed-container',
            });
        }
        this._box = box;

        // 上传标签（上方）
        this._uploadLabel = new St.Label({
            text: '▲     0  B/s',
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'net-speed-label net-speed-upload',
        });

        // 下载标签（下方）
        this._downloadLabel = new St.Label({
            text: '▼     0  B/s',
            y_align: Clutter.ActorAlign.CENTER,
            style_class: 'net-speed-label net-speed-download',
        });

        this._box.add_child(this._uploadLabel);
        this._box.add_child(this._downloadLabel);
        this.add_child(this._box);

        // 网络流量统计状态
        this._lastRxBytes = 0;
        this._lastTxBytes = 0;
        this._lastTime = 0;
        this._timerId = null;

        // 应用字体与颜色样式
        this._applyStyles();

        // 监听配置变更
        this._settingsSignals = [
            this._settings.connect('changed::upload-color', () => this._applyStyles()),
            this._settings.connect('changed::download-color', () => this._applyStyles()),
            this._settings.connect('changed::font-family', () => this._applyStyles()),
            this._settings.connect('changed::font-size', () => this._applyStyles()),
            this._settings.connect('changed::font-bold', () => this._applyStyles()),
            this._settings.connect('changed::upload-prefix', () => this._applyStyles()),
            this._settings.connect('changed::download-prefix', () => this._applyStyles()),
            this._settings.connect('changed::refresh-interval', () => this._restartTimer()),
        ];

        // 构建中文下拉菜单
        this._buildMenu();

        // 初始化基准数据并启动定时器
        const initialStats = this._readNetStats();
        if (initialStats) {
            this._lastRxBytes = initialStats.rx;
            this._lastTxBytes = initialStats.tx;
            this._lastTime = GLib.get_monotonic_time();
        }

        this._restartTimer();
    }

    _buildMenu() {
        this._menuInfoItem = new PopupMenu.PopupMenuItem('实时网络监控', {
            reactive: false,
            can_focus: false,
        });
        this.menu.addMenuItem(this._menuInfoItem);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        const sysMonItem = new PopupMenu.PopupMenuItem('打开系统监视器');
        sysMonItem.connect('activate', () => {
            try {
                const app = Gio.AppInfo.create_from_commandline(
                    'gnome-system-monitor',
                    null,
                    Gio.AppInfoCreateFlags.NONE
                );
                app.launch([], null);
            } catch (e) {
                console.error('NetSpeed: Could not launch gnome-system-monitor', e);
            }
        });
        this.menu.addMenuItem(sysMonItem);

        const prefsItem = new PopupMenu.PopupMenuItem('首选项设置');
        prefsItem.connect('activate', () => {
            if (this._openPrefs) {
                this._openPrefs();
            }
        });
        this.menu.addMenuItem(prefsItem);
    }

    _applyStyles() {
        const uploadColor = this._settings.get_string('upload-color') || '#33d17a';
        const downloadColor = this._settings.get_string('download-color') || '#3584e4';
        const rawFont = this._settings.get_string('font-family') || 'Monospace';
        const fontFamily = rawFont.replace(/['"]/g, '').trim();
        const fontSize = this._settings.get_int('font-size') || 8;
        const isBold = this._settings.get_boolean('font-bold');

        const weightStr = isBold ? 'font-weight: bold;' : 'font-weight: normal;';
        const commonStyle = `font-family: '${fontFamily}', monospace; font-size: ${fontSize}pt; ${weightStr}`;

        this._uploadLabel.set_style(`color: ${uploadColor}; ${commonStyle}`);
        this._downloadLabel.set_style(`color: ${downloadColor}; ${commonStyle}`);
    }

    _formatSpeed(bytesPerSec) {
        if (bytesPerSec < 0 || isNaN(bytesPerSec)) {
            bytesPerSec = 0;
        }

        let numStr;
        let unit;

        // B/s 前面留出一个空格（' B/s'），使其与 'KB/s'、'MB/s'、'GB/s' 同为 4 字符，确保 B/s 位置恒定不变
        if (bytesPerSec < 1024) {
            numStr = Math.round(bytesPerSec).toString().padStart(4, ' ');
            unit = ' B/s';
        } else if (bytesPerSec < 1024 * 1024) {
            const kb = bytesPerSec / 1024;
            numStr = (kb >= 100 ? kb.toFixed(0) : kb.toFixed(1)).padStart(4, ' ');
            unit = 'KB/s';
        } else if (bytesPerSec < 1024 * 1024 * 1024) {
            const mb = bytesPerSec / (1024 * 1024);
            numStr = (mb >= 100 ? mb.toFixed(0) : mb.toFixed(1)).padStart(4, ' ');
            unit = 'MB/s';
        } else {
            const gb = bytesPerSec / (1024 * 1024 * 1024);
            numStr = (gb >= 10 ? gb.toFixed(1) : gb.toFixed(2)).padStart(4, ' ');
            unit = 'GB/s';
        }

        return `${numStr} ${unit}`;
    }

    _readNetStats() {
        try {
            const [ok, contents] = GLib.file_get_contents('/proc/net/dev');
            if (!ok) return null;

            const text = new TextDecoder('utf-8').decode(contents);
            const lines = text.split('\n');

            let totalRx = 0;
            let totalTx = 0;

            for (let i = 2; i < lines.length; i++) {
                const line = lines[i].trim();
                if (!line) continue;

                const colonIdx = line.indexOf(':');
                if (colonIdx === -1) continue;

                const iface = line.substring(0, colonIdx).trim();
                if (iface === 'lo') continue;

                const fields = line.substring(colonIdx + 1).trim().split(/\s+/);
                if (fields.length >= 9) {
                    const rx = parseInt(fields[0], 10) || 0;
                    const tx = parseInt(fields[8], 10) || 0;
                    totalRx += rx;
                    totalTx += tx;
                }
            }

            return { rx: totalRx, tx: totalTx };
        } catch (e) {
            console.error('NetSpeed: Error reading /proc/net/dev', e);
            return null;
        }
    }

    _updateSpeed() {
        const stats = this._readNetStats();
        if (!stats) return;

        const now = GLib.get_monotonic_time();
        const elapsedSec = (now - this._lastTime) / 1000000.0;

        if (this._lastTime > 0 && elapsedSec > 0.1) {
            const rxDiff = Math.max(0, stats.rx - this._lastRxBytes);
            const txDiff = Math.max(0, stats.tx - this._lastTxBytes);

            const rxSpeed = rxDiff / elapsedSec;
            const txSpeed = txDiff / elapsedSec;

            const upPrefix = this._settings.get_string('upload-prefix') || '▲';
            const downPrefix = this._settings.get_string('download-prefix') || '▼';

            // 箭头与网速数字之间使用两个空格拉开距离
            const upText = `${upPrefix}  ${this._formatSpeed(txSpeed)}`;
            const downText = `${downPrefix}  ${this._formatSpeed(rxSpeed)}`;

            this._uploadLabel.set_text(upText);
            this._downloadLabel.set_text(downText);

            if (this._menuInfoItem) {
                this._menuInfoItem.label.set_text(
                    `上传: ${this._formatSpeed(txSpeed).trim()} | 下载: ${this._formatSpeed(rxSpeed).trim()}`
                );
            }
        }

        this._lastRxBytes = stats.rx;
        this._lastTxBytes = stats.tx;
        this._lastTime = now;
    }

    _restartTimer() {
        if (this._timerId) {
            GLib.source_remove(this._timerId);
            this._timerId = null;
        }

        const interval = Math.max(1, this._settings.get_int('refresh-interval') || 1);
        this._timerId = GLib.timeout_add_seconds(
            GLib.PRIORITY_DEFAULT,
            interval,
            () => {
                this._updateSpeed();
                return GLib.SOURCE_CONTINUE;
            }
        );
    }

    destroy() {
        if (this._timerId) {
            GLib.source_remove(this._timerId);
            this._timerId = null;
        }

        if (this._settingsSignals && this._settings) {
            for (const sigId of this._settingsSignals) {
                this._settings.disconnect(sigId);
            }
            this._settingsSignals = [];
        }

        super.destroy();
    }
});

export default class NetSpeedVerticalExtension extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._indicator = new NetSpeedIndicator(this._settings, () => this.openPreferences());
        Main.panel.addToStatusArea(this.uuid, this._indicator);
    }

    disable() {
        if (this._indicator) {
            this._indicator.destroy();
            this._indicator = null;
        }
        this._settings = null;
    }
}
