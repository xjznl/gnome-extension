import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {AnnotationCanvas, TOOLS, COLORS, WIDTHS} from './canvas.js';
import {runNativeSaveWithAnnotations} from './compositor.js';
import {t} from './i18n.js';

export default class ScreenshotAnnotatorExtension extends Extension {
    enable() {
        this._ui = Main.screenshotUI;
        if (!this._ui) {
            console.error('[screenshot-annotator] Main.screenshotUI is unavailable');
            return;
        }

        this._signals = [];
        this._toolButtons = new Map();
        this._colorButtons = new Map();
        this._widthButtons = new Map();
        this._keyController = null;
        this._repositionIdleId = 0;

        this._buildOverlay();
        this._hookScreenshotUI();
    }

    disable() {
        // Must remain synchronous in GNOME Shell 51
        if (this._repositionIdleId) {
            GLib.source_remove(this._repositionIdleId);
            this._repositionIdleId = 0;
        }

        if (this._ui?._areaSelector)
            this._ui._areaSelector.reactive = true;

        this._unhookScreenshotUI();

        if (this._keyController && this._ui) {
            try {
                this._ui.remove_action(this._keyController);
            } catch {
                // Ignore if already detached
            }
            this._keyController = null;
        }

        if (this._toolbar) {
            this._toolbar.destroy();
            this._toolbar = null;
        }

        if (this._canvas) {
            this._canvas.destroy();
            this._canvas = null;
        }

        this._toolButtons?.clear();
        this._colorButtons?.clear();
        this._widthButtons?.clear();
        this._ui = null;
    }

    _buildOverlay() {
        // 1. Full-stage annotation drawing canvas
        this._canvas = new AnnotationCanvas(this._ui);
        this._canvas.add_constraint(new Clutter.BindConstraint({
            source: this._ui,
            coordinate: Clutter.BindCoordinate.ALL,
        }));
        this._canvas.visible = false;

        // Resolve the direct child of ScreenshotUI that owns _panel (usually _primaryMonitorBin)
        let panelAnchor = this._ui._panel ?? null;
        while (panelAnchor && panelAnchor.get_parent() !== this._ui)
            panelAnchor = panelAnchor.get_parent();

        if (panelAnchor)
            this._ui.insert_child_below(this._canvas, panelAnchor);
        else
            this._ui.add_child(this._canvas);

        // 2. Floating annotation toolbar (GNOME 51: Clutter.Orientation.HORIZONTAL)
        this._toolbar = new St.BoxLayout({
            style_class: 'screenshot-annotator-toolbar',
            orientation: Clutter.Orientation.HORIZONTAL,
            reactive: true,
            visible: false,
        });

        // Tool buttons (auto-localized EN / ZH)
        for (const tool of TOOLS) {
            const btn = new St.Button({
                style_class: 'screenshot-annotator-btn',
                label: t(tool.key),
                can_focus: false,
                toggle_mode: true,
            });
            btn.connect('clicked', () => this._selectTool(tool.id));
            this._toolButtons.set(tool.id, btn);
            this._toolbar.add_child(btn);
        }

        this._toolbar.add_child(new St.Widget({style_class: 'screenshot-annotator-sep'}));

        // Color swatches
        for (const color of COLORS) {
            const swatch = new St.Button({
                style_class: 'screenshot-annotator-color-btn',
                can_focus: false,
            });
            swatch.set_style(`background-color: ${color.hex};`);
            swatch.connect('clicked', () => this._selectColor(color.id));
            this._colorButtons.set(color.id, swatch);
            this._toolbar.add_child(swatch);
        }

        this._toolbar.add_child(new St.Widget({style_class: 'screenshot-annotator-sep'}));

        // Stroke width toggles
        for (const w of WIDTHS) {
            const btn = new St.Button({
                style_class: 'screenshot-annotator-width-btn',
                label: t(w.key),
                can_focus: false,
            });
            btn.connect('clicked', () => this._selectWidth(w.id));
            this._widthButtons.set(w.id, btn);
            this._toolbar.add_child(btn);
        }

        this._toolbar.add_child(new St.Widget({style_class: 'screenshot-annotator-sep'}));

        // Undo & Clear actions
        this._undoBtn = new St.Button({
            style_class: 'screenshot-annotator-btn',
            label: t('undo'),
            can_focus: false,
        });
        this._undoBtn.connect('clicked', () => this._canvas.undo());
        this._toolbar.add_child(this._undoBtn);

        this._clearBtn = new St.Button({
            style_class: 'screenshot-annotator-btn screenshot-annotator-danger-btn',
            label: t('clear'),
            can_focus: false,
        });
        this._clearBtn.connect('clicked', () => this._canvas.clear());
        this._toolbar.add_child(this._clearBtn);

        this._ui.add_child(this._toolbar);

        // Default selections
        this._selectTool('select');
        this._selectColor(COLORS[0].id);
        this._selectWidth(WIDTHS[1].id);

        // Modern GNOME 51 Clutter.KeyController for Ctrl+Z undo
        this._keyController = new Clutter.KeyController();
        this._keyController.connect('key-press', () => {
            if (!this._toolbar?.visible)
                return Clutter.EVENT_PROPAGATE;

            const [, symbol] = this._keyController.get_key();
            const ev = this._keyController.get_current_event?.();
            const state = ev ? ev.get_state() : global.get_pointer()[2];
            const ctrl = (state & Clutter.ModifierType.CONTROL_MASK) !== 0;

            if (ctrl && (symbol === Clutter.KEY_z || symbol === Clutter.KEY_Z)) {
                this._canvas.undo();
                return Clutter.EVENT_STOP;
            }

            return Clutter.EVENT_PROPAGATE;
        });
        this._ui.add_action(this._keyController);
    }

    _scheduleReposition() {
        if (this._repositionIdleId)
            return;

        this._repositionIdleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this._repositionIdleId = 0;
            this._repositionToolbar();
            return GLib.SOURCE_REMOVE;
        });
    }

    _repositionToolbar() {
        if (!this._ui || !this._toolbar || !this._toolbar.visible)
            return;

        if (this._canvas && this._ui.width > 0 && this._ui.height > 0) {
            this._canvas.set_position(0, 0);
            this._canvas.set_size(this._ui.width, this._ui.height);
        }

        const monitor = Main.layoutManager.primaryMonitor;
        if (!monitor)
            return;

        const [, natW] = this._toolbar.get_preferred_width(-1);
        const [, natH] = this._toolbar.get_preferred_height(-1);

        let x = Math.round(monitor.x + (monitor.width - natW) / 2);
        let y = Math.round(monitor.y + monitor.height - natH - 165);

        if (this._ui._panel && this._ui._panel.visible) {
            const [panelX, panelY] = this._ui._panel.get_transformed_position();
            const [panelW] = this._ui._panel.get_transformed_size();
            if (panelW > 0 && panelY > monitor.y) {
                x = Math.round(panelX + (panelW - natW) / 2);
                y = Math.round(panelY - natH - 14);
            }
        }

        x = Math.max(monitor.x + 12, Math.min(monitor.x + monitor.width - natW - 12, x));
        y = Math.max(monitor.y + 12, Math.min(monitor.y + monitor.height - natH - 12, y));

        this._toolbar.set_position(x, y);
        this._ui.set_child_above_sibling(this._toolbar, null);
    }

    _selectTool(toolId) {
        this._canvas.setTool(toolId);

        if (this._ui?._areaSelector)
            this._ui._areaSelector.reactive = toolId === 'select';

        for (const [id, btn] of this._toolButtons.entries()) {
            const active = id === toolId;
            btn.checked = active;
            if (active)
                btn.add_style_class_name('active');
            else
                btn.remove_style_class_name('active');
        }
    }

    _selectColor(colorId) {
        const entry = COLORS.find(c => c.id === colorId);
        if (!entry)
            return;
        this._canvas.setColor(entry.rgba);
        for (const [id, btn] of this._colorButtons.entries()) {
            if (id === colorId)
                btn.add_style_class_name('active');
            else
                btn.remove_style_class_name('active');
        }
    }

    _selectWidth(widthId) {
        const entry = WIDTHS.find(w => w.id === widthId);
        if (!entry)
            return;
        this._canvas.setLineWidth(entry.value);
        for (const [id, btn] of this._widthButtons.entries()) {
            if (id === widthId)
                btn.add_style_class_name('active');
            else
                btn.remove_style_class_name('active');
        }
    }

    _updateVisibility() {
        if (!this._ui || !this._toolbar || !this._canvas)
            return;

        const isVisible = this._ui.visible;
        const isScreenshotMode = this._ui._shotButton ? this._ui._shotButton.checked : true;
        const isWindowMode = this._ui._windowButton ? this._ui._windowButton.checked : false;

        const show = isVisible && isScreenshotMode && !isWindowMode;
        this._toolbar.visible = show;
        this._canvas.visible = show;

        if (show) {
            this._scheduleReposition();
        } else {
            this._canvas.clear();
            this._selectTool('select');
        }
    }

    _connectSignal(obj, signal, callback) {
        if (!obj)
            return;
        const id = obj.connect(signal, callback);
        this._signals.push({obj, id});
    }

    _hookScreenshotUI() {
        const ui = this._ui;
        this._connectSignal(ui, 'notify::visible', () => this._updateVisibility());
        this._connectSignal(ui, 'notify::allocation', () => this._scheduleReposition());
        this._connectSignal(ui._panel, 'notify::allocation', () => this._scheduleReposition());
        this._connectSignal(ui._shotButton, 'notify::checked', () => this._updateVisibility());
        this._connectSignal(ui._castButton, 'notify::checked', () => this._updateVisibility());
        this._connectSignal(ui._selectionButton, 'notify::checked', () => this._updateVisibility());
        this._connectSignal(ui._screenButton, 'notify::checked', () => this._updateVisibility());
        this._connectSignal(ui._windowButton, 'notify::checked', () => this._updateVisibility());

        this._origSaveScreenshot = ui._saveScreenshot;
        const ext = this;

        ui._saveScreenshot = function (...args) {
            ext._canvas?.commitPending();
            const annotations = ext._canvas?.annotations ?? [];

            if (annotations.length === 0)
                return ext._origSaveScreenshot.apply(this, args);

            const snapshot = [...annotations];
            return runNativeSaveWithAnnotations(this, ext._origSaveScreenshot, args, snapshot);
        };

        this._updateVisibility();
    }

    _unhookScreenshotUI() {
        if (this._signals) {
            for (const {obj, id} of this._signals) {
                try {
                    obj.disconnect(id);
                } catch {
                    // Ignore already-destroyed objects
                }
            }
            this._signals = [];
        }

        if (this._ui && this._origSaveScreenshot) {
            this._ui._saveScreenshot = this._origSaveScreenshot;
            this._origSaveScreenshot = null;
        }
    }
}
