import Cairo from 'gi://cairo';
import GdkPixbuf from 'gi://GdkPixbuf';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Shell from 'gi://Shell';

import {drawAnnotation} from './canvas.js';

/**
 * Apply true block-averaged mosaic pixelation directly onto a GdkPixbuf
 * using native C downscale/upscale operations for speed and reliability.
 */
function applyMosaicRegions(basePixbuf, annotations, originX, originY, scale) {
    const imgW = basePixbuf.get_width();
    const imgH = basePixbuf.get_height();

    for (const item of annotations) {
        if (item.type !== 'mosaic')
            continue;

        const rx1 = Math.round(Math.min(item.x1, item.x2) * scale - originX);
        const ry1 = Math.round(Math.min(item.y1, item.y2) * scale - originY);
        const rx2 = Math.round(Math.max(item.x1, item.x2) * scale - originX);
        const ry2 = Math.round(Math.max(item.y1, item.y2) * scale - originY);

        const cx = Math.max(0, Math.min(imgW, rx1));
        const cy = Math.max(0, Math.min(imgH, ry1));
        const cw = Math.max(0, Math.min(imgW, rx2) - cx);
        const ch = Math.max(0, Math.min(imgH, ry2) - cy);

        if (cw < 2 || ch < 2)
            continue;

        const blockPx = Math.max(4, Math.round((item.blockSize ?? 14) * scale));
        const smallW = Math.max(1, Math.round(cw / blockPx));
        const smallH = Math.max(1, Math.round(ch / blockPx));

        const sub = basePixbuf.new_subpixbuf(cx, cy, cw, ch);
        const down = sub.scale_simple(smallW, smallH, GdkPixbuf.InterpType.BILINEAR);
        const pixelated = down.scale_simple(cw, ch, GdkPixbuf.InterpType.NEAREST);
        pixelated.copy_area(0, 0, cw, ch, basePixbuf, cx, cy);
    }
}

/**
 * Render vector and text annotations onto a transparent Cairo surface and
 * alpha-composite them onto the base GdkPixbuf.
 */
function compositeVectorAnnotations(basePixbuf, annotations, originX, originY, scale) {
    const hasVectors = annotations.some(a => a.type !== 'mosaic');
    if (!hasVectors)
        return;

    const imgW = basePixbuf.get_width();
    const imgH = basePixbuf.get_height();

    const surface = new Cairo.ImageSurface(Cairo.Format.ARGB32, imgW, imgH);
    const cr = new Cairo.Context(surface);

    cr.translate(-originX, -originY);
    cr.scale(scale, scale);

    for (const item of annotations) {
        if (item.type !== 'mosaic')
            drawAnnotation(cr, item, false);
    }

    const tmpPath = GLib.build_filenamev([
        GLib.get_tmp_dir(),
        `gnome-screenshot-annot-${GLib.get_monotonic_time()}.png`,
    ]);

    try {
        surface.writeToPNG(tmpPath);
        const overlayPixbuf = GdkPixbuf.Pixbuf.new_from_file(tmpPath);
        overlayPixbuf.composite(
            basePixbuf,
            0, 0, imgW, imgH,
            0, 0, 1.0, 1.0,
            GdkPixbuf.InterpType.NEAREST,
            255
        );
    } finally {
        cr.$dispose();
        const tmpFile = Gio.File.new_for_path(tmpPath);
        try {
            tmpFile.delete(null);
        } catch {
            // Ignore temp cleanup errors
        }
    }
}

/**
 * Execute GNOME Shell's own native `_saveScreenshot` while temporarily
 * intercepting `Shell.Screenshot.composite_to_stream` to composite annotations
 * into the PNG stream. This preserves 100% of GNOME's native saving,
 * localization, clipboard, shutter sound, flash effect, and Screen Capture
 * notification (including exact native icon and thumbnail preview).
 */
export function runNativeSaveWithAnnotations(ui, origSaveScreenshot, saveArgs, annotations) {
    const origCompositeToStream = Shell.Screenshot.composite_to_stream;
    let restored = false;

    const restore = () => {
        if (!restored) {
            Shell.Screenshot.composite_to_stream = origCompositeToStream;
            restored = true;
        }
    };

    // Safety fallback timer in case _saveScreenshot aborts before calling composite_to_stream
    const fallbackTimeoutId = GLib.timeout_add_seconds(GLib.PRIORITY_DEFAULT, 5, () => {
        restore();
        return GLib.SOURCE_REMOVE;
    });

    Shell.Screenshot.composite_to_stream = async function (
        texture,
        x, y, width, height,
        scale,
        cursorTexture,
        cursorX, cursorY, cursorScale,
        targetStream
    ) {
        restore();
        GLib.source_remove(fallbackTimeoutId);

        const tempStream = Gio.MemoryOutputStream.new_resizable();
        const origPixbuf = await origCompositeToStream.call(
            this,
            texture,
            x, y, width, height,
            scale,
            cursorTexture,
            cursorX, cursorY, cursorScale,
            tempStream
        );
        tempStream.close(null);

        try {
            const rawBytes = tempStream.steal_as_bytes();
            const loader = GdkPixbuf.PixbufLoader.new_with_type('png');
            loader.write_bytes(rawBytes);
            loader.close();

            const basePixbuf = loader.get_pixbuf() ?? origPixbuf;
            if (!basePixbuf)
                throw new Error('Failed to decode base screenshot pixbuf');

            const effScale = scale || 1;
            applyMosaicRegions(basePixbuf, annotations, x, y, effScale);
            compositeVectorAnnotations(basePixbuf, annotations, x, y, effScale);

            const [ok, pngBuffer] = basePixbuf.save_to_bufferv('png', [], []);
            if (!ok)
                throw new Error('Failed to encode annotated PNG buffer');

            targetStream.write_bytes(GLib.Bytes.new(pngBuffer), null);
            return basePixbuf;
        } catch (err) {
            console.error('[screenshot-annotator] Compositing failed, writing original image:', err);
            const fallbackBytes = tempStream.steal_as_bytes();
            if (fallbackBytes)
                targetStream.write_bytes(fallbackBytes, null);
            return origPixbuf;
        }
    };

    try {
        return origSaveScreenshot.apply(ui, saveArgs);
    } catch (err) {
        restore();
        GLib.source_remove(fallbackTimeoutId);
        throw err;
    }
}
