import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Shell from 'gi://Shell';
import St from 'gi://St';
import Cairo from 'gi://cairo';
import Pango from 'gi://Pango';
import PangoCairo from 'gi://PangoCairo';
import * as IBusManager from 'resource:///org/gnome/shell/misc/ibusManager.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import {t} from './i18n.js';

export const TOOLS = [
    {id: 'select', key: 'select'},
    {id: 'arrow', key: 'arrow'},
    {id: 'rect', key: 'rect'},
    {id: 'brush', key: 'brush'},
    {id: 'text', key: 'text'},
    {id: 'mosaic', key: 'mosaic'},
];

export const COLORS = [
    {id: 'red', hex: '#e01b24', rgba: [0.878, 0.106, 0.141, 1.0]},
    {id: 'yellow', hex: '#f6d32d', rgba: [0.965, 0.827, 0.176, 1.0]},
    {id: 'blue', hex: '#3584e4', rgba: [0.208, 0.518, 0.894, 1.0]},
    {id: 'green', hex: '#33d17a', rgba: [0.200, 0.820, 0.478, 1.0]},
    {id: 'white', hex: '#ffffff', rgba: [1.0, 1.0, 1.0, 1.0]},
    {id: 'black', hex: '#1e1e1e', rgba: [0.118, 0.118, 0.118, 1.0]},
];

export const WIDTHS = [
    {id: 'thin', key: 'thin', value: 2.5},
    {id: 'medium', key: 'medium', value: 4.5},
    {id: 'thick', key: 'thick', value: 8.0},
];

/**
 * Render a single vector/text annotation onto a Cairo context.
 * Mosaic preview is drawn only when `forPreview` is true (final capture uses
 * real pixel-block averaging on the underlying GdkPixbuf).
 */
export function drawAnnotation(cr, item, forPreview = false) {
    if (!item)
        return;

    const [r, g, b, a] = item.color ?? [0.878, 0.106, 0.141, 1.0];
    const lineWidth = item.lineWidth ?? 4.5;

    cr.save();
    cr.setLineCap(Cairo.LineCap.ROUND);
    cr.setLineJoin(Cairo.LineJoin.ROUND);

    switch (item.type) {
    case 'arrow': {
        const dx = item.x2 - item.x1;
        const dy = item.y2 - item.y1;
        const len = Math.hypot(dx, dy);
        if (len < 2)
            break;

        const angle = Math.atan2(dy, dx);
        const headLen = Math.max(14, lineWidth * 4.2);
        const headAngle = Math.PI / 6.5;

        const shaftEndX = item.x2 - Math.cos(angle) * (headLen * 0.65);
        const shaftEndY = item.y2 - Math.sin(angle) * (headLen * 0.65);

        cr.setSourceRGBA(r, g, b, a);
        cr.setLineWidth(lineWidth);
        cr.moveTo(item.x1, item.y1);
        cr.lineTo(shaftEndX, shaftEndY);
        cr.stroke();

        cr.moveTo(item.x2, item.y2);
        cr.lineTo(
            item.x2 - headLen * Math.cos(angle - headAngle),
            item.y2 - headLen * Math.sin(angle - headAngle)
        );
        cr.lineTo(
            item.x2 - headLen * Math.cos(angle + headAngle),
            item.y2 - headLen * Math.sin(angle + headAngle)
        );
        cr.closePath();
        cr.fill();
        break;
    }

    case 'rect': {
        const rx = Math.min(item.x1, item.x2);
        const ry = Math.min(item.y1, item.y2);
        const rw = Math.abs(item.x2 - item.x1);
        const rh = Math.abs(item.y2 - item.y1);
        if (rw < 2 || rh < 2)
            break;

        cr.setSourceRGBA(r, g, b, a);
        cr.setLineWidth(lineWidth);
        cr.rectangle(rx, ry, rw, rh);
        cr.stroke();
        break;
    }

    case 'brush': {
        const pts = item.points;
        if (!pts || pts.length < 2)
            break;

        cr.setSourceRGBA(r, g, b, a);
        cr.setLineWidth(lineWidth);
        cr.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < pts.length; i++)
            cr.lineTo(pts[i].x, pts[i].y);
        cr.stroke();
        break;
    }

    case 'text': {
        if (!item.text || item.text.trim().length === 0)
            break;

        const fontSize = Math.round(14 + lineWidth * 2.2);
        const layout = PangoCairo.create_layout(cr);
        const fontDesc = Pango.FontDescription.from_string(`Sans Bold ${fontSize}`);
        layout.set_font_description(fontDesc);
        layout.set_text(item.text, -1);

        cr.moveTo(item.x + 1.5, item.y + 1.5);
        cr.setSourceRGBA(0, 0, 0, 0.55);
        PangoCairo.show_layout(cr, layout);

        cr.moveTo(item.x, item.y);
        cr.setSourceRGBA(r, g, b, a);
        PangoCairo.show_layout(cr, layout);
        break;
    }

    case 'mosaic': {
        if (!forPreview)
            break;

        const mx = Math.min(item.x1, item.x2);
        const my = Math.min(item.y1, item.y2);
        const mw = Math.abs(item.x2 - item.x1);
        const mh = Math.abs(item.y2 - item.y1);
        if (mw < 2 || mh < 2)
            break;

        const cell = item.blockSize ?? 12;
        cr.save();
        cr.rectangle(mx, my, mw, mh);
        cr.clip();

        for (let y = my; y < my + mh; y += cell) {
            for (let x = mx; x < mx + mw; x += cell) {
                const odd = (Math.floor((x - mx) / cell) + Math.floor((y - my) / cell)) % 2 === 0;
                if (odd)
                    cr.setSourceRGBA(0.18, 0.18, 0.18, 0.72);
                else
                    cr.setSourceRGBA(0.55, 0.55, 0.55, 0.72);
                cr.rectangle(x, y, cell, cell);
                cr.fill();
            }
        }
        cr.restore();

        cr.setSourceRGBA(1, 1, 1, 0.85);
        cr.setLineWidth(1.5);
        cr.setDash([5, 4], 0);
        cr.rectangle(mx, my, mw, mh);
        cr.stroke();
        break;
    }
    }

    cr.restore();
}

export const AnnotationCanvas = GObject.registerClass({
    Signals: {
        'annotations-changed': {},
    },
}, class AnnotationCanvas extends St.DrawingArea {
    _init(parentContainer) {
        super._init({
            style_class: 'screenshot-annotator-canvas',
            reactive: false,
            can_focus: false,
            x_expand: true,
            y_expand: true,
        });

        this._parentContainer = parentContainer;
        this._annotations = [];
        this._draft = null;
        this._isDrawing = false;

        this._activeTool = 'select';
        this._activeColor = COLORS[0].rgba;
        this._activeWidth = WIDTHS[1].value;
        this._mosaicBlockSize = 14;

        this._textEntry = null;
        this._textEntryPos = null;
        this._focusIdleId = 0;
        this._textModalGrab = null;
        this._reparentedPopup = null;
        this._popupOrigParent = null;

        this.connect('repaint', this._onRepaint.bind(this));
        this.connect('button-press-event', this._onButtonPress.bind(this));
        this.connect('motion-event', this._onMotion.bind(this));
        this.connect('button-release-event', this._onButtonRelease.bind(this));
    }

    get annotations() {
        return this._annotations;
    }

    get activeTool() {
        return this._activeTool;
    }

    setTool(toolId) {
        this._commitActiveText();
        this._activeTool = toolId;
        this.reactive = toolId !== 'select';
        this._updateCursor();
    }

    setColor(rgba) {
        this._activeColor = rgba;
    }

    setLineWidth(width) {
        this._activeWidth = width;
    }

    undo() {
        this._cancelActiveText();
        if (this._annotations.length > 0) {
            this._annotations.pop();
            this.queue_repaint();
            this.emit('annotations-changed');
        }
    }

    clear() {
        this._cancelActiveText();
        this._draft = null;
        this._isDrawing = false;
        if (this._annotations.length > 0) {
            this._annotations = [];
            this.queue_repaint();
            this.emit('annotations-changed');
        } else {
            this.queue_repaint();
        }
    }

    commitPending() {
        this._commitActiveText();
    }

    _updateCursor() {
        const cursorType = this._activeTool === 'select'
            ? Clutter.CursorType.DEFAULT
            : Clutter.CursorType.CROSSHAIR;
        try {
            global.display.set_cursor(cursorType);
        } catch {
            // Ignore cursor updates if display cursor API differs
        }
    }

    _resolveIBusPopupActor() {
        try {
            const ibusManager = IBusManager.getIBusManager();
            const popup = ibusManager?._candidatePopup;
            if (!popup)
                return null;
            if (popup instanceof Clutter.Actor)
                return popup;
            if (popup._boxPointer instanceof Clutter.Actor)
                return popup._boxPointer;
        } catch {
            // Ignore if IBusManager is unavailable
        }
        return null;
    }

    /**
     * Temporarily reparent GNOME Shell's native IBus candidate popup directly
     * inside Main.screenshotUI (on top of all children) and push an OVERVIEW
     * modal grab so IBus works and renders directly over the screenshot canvas,
     * regardless of which stage container ScreenshotUI lives in.
     */
    _enterImeMode() {
        if (!this._reparentedPopup && this._parentContainer) {
            try {
                const popupActor = this._resolveIBusPopupActor();
                const origParent = popupActor?.get_parent();
                if (popupActor && origParent && origParent !== this._parentContainer) {
                    origParent.remove_child(popupActor);
                    this._parentContainer.add_child(popupActor);
                    this._parentContainer.set_child_above_sibling(popupActor, null);
                    this._reparentedPopup = popupActor;
                    this._popupOrigParent = origParent;
                } else if (popupActor && origParent === this._parentContainer) {
                    this._parentContainer.set_child_above_sibling(popupActor, null);
                }
            } catch (err) {
                console.error('[screenshot-annotator] Failed to reparent IBus popup:', err);
            }
        }

        if (!this._textModalGrab && this._parentContainer) {
            try {
                this._textModalGrab = Main.pushModal(this._parentContainer, {
                    actionMode: Shell.ActionMode.OVERVIEW,
                });
            } catch {
                this._textModalGrab = null;
            }
        }
    }

    _leaveImeMode() {
        try {
            Main.inputMethod?.reset?.();
        } catch {
            // Ignore
        }

        if (this._textModalGrab) {
            try {
                Main.popModal(this._textModalGrab);
            } catch {
                // Ignore
            }
            this._textModalGrab = null;
        }

        if (this._reparentedPopup && this._popupOrigParent) {
            try {
                if (this._reparentedPopup.get_parent() === this._parentContainer) {
                    this._parentContainer.remove_child(this._reparentedPopup);
                    this._popupOrigParent.add_child(this._reparentedPopup);
                }
            } catch (err) {
                console.error('[screenshot-annotator] Failed to restore IBus popup:', err);
            }
            this._reparentedPopup = null;
            this._popupOrigParent = null;
        }
    }

    _onRepaint() {
        const cr = this.get_context();
        const [width, height] = this.get_surface_size();

        cr.setOperator(Cairo.Operator.CLEAR);
        cr.paint();
        cr.setOperator(Cairo.Operator.OVER);

        if (width <= 0 || height <= 0) {
            cr.$dispose();
            return;
        }

        for (const item of this._annotations)
            drawAnnotation(cr, item, true);

        if (this._draft)
            drawAnnotation(cr, this._draft, true);

        cr.$dispose();
    }

    _toLocalCoords(event) {
        const [stageX, stageY] = event.get_coords();
        const [ok, localX, localY] = this.transform_stage_point(stageX, stageY);
        return ok ? [localX, localY] : [stageX, stageY];
    }

    _onButtonPress(_actor, event) {
        if (this._activeTool === 'select')
            return Clutter.EVENT_PROPAGATE;

        if (event.get_button() !== Clutter.BUTTON_PRIMARY)
            return Clutter.EVENT_PROPAGATE;

        const [x, y] = this._toLocalCoords(event);

        if (this._activeTool === 'text') {
            this._commitActiveText();
            this._openTextEntry(x, y);
            return Clutter.EVENT_STOP;
        }

        this._isDrawing = true;

        if (this._activeTool === 'brush') {
            this._draft = {
                type: 'brush',
                points: [{x, y}],
                color: [...this._activeColor],
                lineWidth: this._activeWidth,
            };
        } else if (this._activeTool === 'mosaic') {
            this._draft = {
                type: 'mosaic',
                x1: x,
                y1: y,
                x2: x,
                y2: y,
                blockSize: this._mosaicBlockSize,
            };
        } else {
            this._draft = {
                type: this._activeTool,
                x1: x,
                y1: y,
                x2: x,
                y2: y,
                color: [...this._activeColor],
                lineWidth: this._activeWidth,
            };
        }

        this.queue_repaint();
        return Clutter.EVENT_STOP;
    }

    _onMotion(_actor, event) {
        if (!this._isDrawing || !this._draft)
            return Clutter.EVENT_PROPAGATE;

        const [x, y] = this._toLocalCoords(event);

        if (this._draft.type === 'brush') {
            const pts = this._draft.points;
            const last = pts[pts.length - 1];
            if (Math.hypot(x - last.x, y - last.y) >= 2.0)
                pts.push({x, y});
        } else {
            this._draft.x2 = x;
            this._draft.y2 = y;
        }

        this.queue_repaint();
        return Clutter.EVENT_STOP;
    }

    _onButtonRelease(_actor, event) {
        if (!this._isDrawing || !this._draft)
            return Clutter.EVENT_PROPAGATE;

        if (event.get_button() !== Clutter.BUTTON_PRIMARY)
            return Clutter.EVENT_PROPAGATE;

        const [x, y] = this._toLocalCoords(event);
        if (this._draft.type === 'brush') {
            this._draft.points.push({x, y});
            if (this._draft.points.length >= 2)
                this._annotations.push(this._draft);
        } else {
            this._draft.x2 = x;
            this._draft.y2 = y;
            if (Math.hypot(this._draft.x2 - this._draft.x1, this._draft.y2 - this._draft.y1) >= 4)
                this._annotations.push(this._draft);
        }

        this._draft = null;
        this._isDrawing = false;
        this.queue_repaint();
        this.emit('annotations-changed');
        return Clutter.EVENT_STOP;
    }

    _openTextEntry(x, y) {
        this._cancelActiveText();

        const entry = new St.Entry({
            style_class: 'screenshot-annotator-text-entry',
            hint_text: t('textHint'),
            can_focus: true,
            reactive: true,
        });

        const [r, g, b] = this._activeColor;
        const cssColor = `rgb(${Math.round(r * 255)}, ${Math.round(g * 255)}, ${Math.round(b * 255)})`;
        const fontSize = Math.round(14 + this._activeWidth * 2.2);
        entry.set_style(`color: ${cssColor}; font-size: ${fontSize}px;`);

        entry.set_position(Math.max(8, x - 6), Math.max(8, y - 6));

        const clutterText = entry.get_clutter_text();
        clutterText.set_editable(true);
        clutterText.set_selectable(true);
        clutterText.set_activatable(true);
        if (Clutter.InputContentPurpose?.NORMAL !== undefined)
            clutterText.set_input_purpose(Clutter.InputContentPurpose.NORMAL);

        clutterText.connect('activate', () => {
            this._commitActiveText();
        });

        const keyController = new Clutter.KeyController();
        keyController.connect('key-press', () => {
            const [, symbol] = keyController.get_key();
            if (symbol === Clutter.KEY_Escape) {
                this._cancelActiveText();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });
        entry.add_action(keyController);

        this._textEntry = entry;
        this._textEntryPos = {x, y};

        if (this._parentContainer) {
            this._parentContainer.add_child(entry);
            this._parentContainer.set_child_above_sibling(entry, null);
            // Reparent IBus candidate popup into ScreenshotUI ABOVE entry
            this._enterImeMode();

            this._focusIdleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._focusIdleId = 0;
                if (this._textEntry) {
                    const ct = this._textEntry.get_clutter_text();
                    global.stage.set_key_focus(ct);
                    ct.grab_key_focus();
                    if (this._reparentedPopup && this._reparentedPopup.get_parent() === this._parentContainer)
                        this._parentContainer.set_child_above_sibling(this._reparentedPopup, null);
                }
                return GLib.SOURCE_REMOVE;
            });
        }
    }

    _commitActiveText() {
        if (!this._textEntry)
            return;

        const text = this._textEntry.get_text();
        const pos = this._textEntryPos;
        this._cancelActiveText();

        if (text && text.trim().length > 0 && pos) {
            this._annotations.push({
                type: 'text',
                x: pos.x,
                y: pos.y,
                text: text.trim(),
                color: [...this._activeColor],
                lineWidth: this._activeWidth,
            });
            this.queue_repaint();
            this.emit('annotations-changed');
        }
    }

    _cancelActiveText() {
        if (this._focusIdleId) {
            GLib.source_remove(this._focusIdleId);
            this._focusIdleId = 0;
        }
        if (this._textEntry) {
            try {
                this._textEntry.get_clutter_text().set_preedit_text(null, 0);
            } catch {
                // Ignore
            }
            this._textEntry.destroy();
            this._textEntry = null;
            this._textEntryPos = null;
        }
        this._leaveImeMode();
    }

    destroy() {
        this._cancelActiveText();
        super.destroy();
    }
});
