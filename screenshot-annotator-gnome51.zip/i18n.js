import GLib from 'gi://GLib';

const STRINGS = {
    en: {
        select: 'Select',
        arrow: 'Arrow',
        rect: 'Rect',
        brush: 'Brush',
        text: 'Text',
        mosaic: 'Mosaic',
        thin: 'S',
        medium: 'M',
        thick: 'L',
        undo: 'Undo',
        clear: 'Clear',
        textHint: 'Type text, Enter to confirm…',
    },
    zh: {
        select: '选区',
        arrow: '箭头',
        rect: '矩形',
        brush: '画笔',
        text: '文字',
        mosaic: '马赛克',
        thin: '细',
        medium: '中',
        thick: '粗',
        undo: '撤销',
        clear: '清空',
        textHint: '输入文字，回车确认…',
    },
};

export function getLocale() {
    try {
        const langs = GLib.get_language_names();
        for (const lang of langs) {
            if (!lang || lang === 'C' || lang === 'POSIX')
                continue;
            if (lang.toLowerCase().startsWith('zh'))
                return 'zh';
            return 'en';
        }
    } catch {
        // Fallback to English
    }
    return 'en';
}

export function t(key) {
    const locale = getLocale();
    return STRINGS[locale]?.[key] ?? STRINGS.en[key] ?? key;
}
