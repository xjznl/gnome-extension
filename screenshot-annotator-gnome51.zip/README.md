# Screenshot Annotator (GNOME Shell 51)

Adds a floating annotation toolbar directly above GNOME 51's built-in interactive screenshot UI (`Print`), allowing you to draw arrows, rectangles, freehand strokes, text, and true pixel mosaic before capturing.

Automatically follows your system locale (**English** and **Chinese / 中文**), saves into GNOME's localized Screenshots folder, copies to the clipboard, and shows a native screenshot notification with a thumbnail preview.

## Features / 功能特性
- **Select / 选区**: Pass-through mode to adjust GNOME's native selection box.
- **Arrow / 箭头**: Click and drag to draw crisp arrows.
- **Rect / 矩形**: Click and drag to draw highlight rectangles.
- **Brush / 画笔**: Freehand marker strokes.
- **Text / 文字**: Click anywhere to type text (`Enter` to confirm, `Esc` to cancel).
- **Mosaic / 马赛克**: Drag over sensitive areas for true block-averaged pixelation at capture time.
- **Colors & Widths / 颜色与粗细**: 6 preset colors, 3 stroke widths, Undo (`Ctrl+Z`), and Clear.
- **Native Integration / 原生集成**: Saves to GNOME's localized Screenshots directory, copies PNG to clipboard, and shows a native thumbnail preview notification (click to open image or **Show in Files**).

## Installation / 安装方法 (GNOME 51)
```bash
gnome-extensions install --force screenshot-annotator-gnome51.zip
```
Log out and log back in (required on Wayland to reload Shell extension JS), then enable:
```bash
gnome-extensions enable screenshot-annotator@local
```

## Debug Logs / 调试日志
```bash
journalctl -f -o cat /usr/bin/gnome-shell
```
